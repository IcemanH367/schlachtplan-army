# Schlachtplan Army – Android

Dies ist die native Android-Hülle für den Schlachtplan Army Builder.

## App
- Paketname: `de.schlachtplan.army`
- App-Name: `Schlachtplan Army`
- minSdk: 24 (Android 7.0+)
- targetSdk: 35
- Lokale HTML-App im WebView
- JavaScript und LocalStorage aktiviert
- Internetzugriff nur für aktuelle MFM-Daten
- Listen bleiben lokal auf dem Gerät gespeichert

## APK automatisch über GitHub bauen
1. Den gesamten Inhalt dieses Ordners in ein GitHub-Repository hochladen.
2. Unter **Actions** den Workflow **Build Android APK** öffnen.
3. **Run workflow** ausführen.
4. Nach Abschluss unter **Artifacts** `Schlachtplan-Army-Android` herunterladen.
5. ZIP entpacken und `Schlachtplan-Army.apk` auf Android installieren.

Beim ersten manuellen APK-Installieren muss Android ggf. die Berechtigung
**„Unbekannte Apps installieren“** für den verwendeten Browser/Dateimanager erlauben.

## Android Studio
Alternativ den Ordner in Android Studio öffnen, Gradle synchronisieren und:
Build > Build APK(s)
