#!/usr/bin/env bash
set -e
gradle assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk Schlachtplan-Army.apk
echo "APK: $(pwd)/Schlachtplan-Army.apk"
